char *mensaje="Hola a todos";
int num1=8;
int num2=10;
