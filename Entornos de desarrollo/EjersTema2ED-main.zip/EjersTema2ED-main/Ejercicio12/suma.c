int suma(int a,int b){
return a+b;}
