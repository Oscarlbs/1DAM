package main

import "fmt"

func main() {
        fmt.Println("Hola, soy Óscar López-Boado")
}
