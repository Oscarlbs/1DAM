
import java.util.GregorianCalendar;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {

		Scanner sn = new Scanner(System.in);
		boolean salir = false;
		String opcion; // Guardamos la informaci�n del usuario

		while (!salir) {

			System.out.println("1. Algortimo 1");
			System.out.println("2. Algortimo 2");
			System.out.println("3. Salir");

			System.out.println("Selecciona una de las opciones");
			opcion = sn.nextLine();

			switch (opcion) {
			case "1":
				System.out.println("Ha seleccionado el algoritmo 1");
				opcion1;
				break;
			case "2":
				System.out.println("Ha seleccionado el algoritmo 2");

				break;
			case "3":
				salir = true;
				System.out.println("Has salido del men�");
				break;
			default:
				System.out.println("Solo n�meros entre 1 y 3");
			}
		}
	}

	// Algoritmo 1
	public static void opcion1(String mes, int a�o) {

			int numeroDias = 0;
			switch (mes.toLowerCase().trim()) {
			case "enero":
			case "marzo":
			case "mayo":
			case "julio":
			case "agosto":
			case "octubre":
			case "diciembre":
			numeroDias = 31;
			break;
			case "abril":
			case "junio":
			case "septiembre":
			case "noviembre":
			numeroDias = 30;
			break;
			case "febrero":

			if (esBisiesto(a�o)) {
			numeroDias = 29;
			} else {
			numeroDias = 28;
			}
			break;

			}

			return;
			}
			public static boolean esBisiesto(int a�o) {

			GregorianCalendar calendar = new GregorianCalendar();
			boolean esBisiesto = false;
			if (calendar.isLeapYear(a�o)) {
			esBisiesto = true;
			}
			return esBisiesto;

			}
}

