import java.util.Scanner;

public class Practica1programaci�n {

	public static void main(String[] args) {

		Scanner sn = new Scanner(System.in);
		boolean salir = false;
		int opcion; // Guardamos la informaci�n del usuario

		while (!salir) {

			System.out.println("1. Opcion 1");
			System.out.println("2. Opcion 2");
			System.out.println("3. Salir");

			System.out.println("Selecciona una de las opciones");
			opcion = sn.nextInt();

			switch (opcion) {
			case 1:
				System.out.println("Ha seleccionado la opcion 1");
				numeroPerfecto();
				break;
			case 2:
				System.out.println("Ha seleccionado la opci�n 2");
				numerosEnteros();
				break;
			case 3:
				salir = true;
				System.out.println("Has salido del men�");
				break;
			default:
				System.out.println("Solo n�meros entre 1 y 3");
			}
		}
	}

	// Algoritmo 1
	public static void numeroPerfecto() {
		int i, suma = 0, n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce un n�mero: ");
		n = sc.nextInt();
		for (i = 1; i < n; i++) { // i son los divisores. Se divide desde 1 hasta n-1
			if (n % i == 0) {
				suma = suma + i; // si es divisor se suma
			}
		}
		if (suma == n) { // si el numero es igual a la suma de sus divisores es perfecto
			System.out.println("Perfecto");
		} else {
			System.out.println("No es perfecto");

		}
	}

	// Algoritmo 2
	public static void numerosEnteros() {
		int num = 0;
		for (i = 0; i > 0; i++) {
			System.out.println("Introduzca un n�mero entero: ");
			scan.next();
			if (i < 0) {
				System.out.println("El n�mero tiene que ser mayor que cero.");
			} else {
				if (num > num + i) {
					System.out.println("El primer n�mero es mayor que el segundo.");
				} else if (num < num + i) {
					System.out.println("El primer n�mero es menor que el segundo.");
				} else {
					System.out.println("El primer n�mero es igual que el segundo.");
				}
			}
			num = scan.nextInt();
		}

	}

	}

		










